"""Tool registry for managing available tools."""
import logging
import time
from typing import TYPE_CHECKING, Any

from ant.tools.base import BaseTool, validate_args
from ant.tools.builtin_tools import bash, edit_file, read_file, write_file
from ant.tools.policy import ToolGovernance

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from ant.core.agent import AgentSession


class ToolRegistry:
    """Registry for all available tools."""
    def __init__(self, governance: ToolGovernance | None = None) -> None:
        """Initialize an empty tool registry"""
        self._tools: dict[str, BaseTool] = {}
        self._governance = governance

    def register(self, tool: BaseTool) -> None:
        """Register a tool"""
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool | None:
        return self._tools.get(name)

    def list_all(self) -> list[BaseTool]:
        """List all registered tools"""
        return list(self._tools.values())

    def get_tool_schemas(self) -> list[dict[str, Any]]:
        """Get tool schemas for all registered tools."""
        return [tool.get_tool_schema() for tool in self._tools.values()]

    async def execute_tool(
            self, name: str, session: "AgentSession", **kwargs: Any
    ) -> str:
        # Lazy import to avoid circular dependency:
        #   registry → sandbox → core.__init__ → agent → registry
        from ant.core.sandbox import SandboxViolation  # noqa: F811

        tool = self.get(name)
        if tool is None:
            logger.warning("Tool not found: %s", name)
            return f"Tool not found: {name}"

        # 执行前 JSON Schema 参数校验：校验失败直接返回错误串（供 LLM 纠错），
        # 不执行工具、不 raise、governance 不计入调用次数。
        ok, validation_error = validate_args(
            tool.get_tool_schema()["function"]["parameters"], kwargs
        )
        if not ok:
            return validation_error

        if self._governance:
            allowed, reason = self._governance.check_permission(name, session)
            if not allowed:
                return f"Tool call denied: {reason}"

        start = time.time()
        try:
            result = await tool.execute(session=session, **kwargs)
            elapsed = time.time() - start
            if self._governance:
                self._governance.record_call(name, kwargs, result, elapsed)
            return result
        except SandboxViolation as e:
            elapsed = time.time() - start
            if self._governance:
                self._governance.record_call(name, kwargs, str(e), elapsed)
            return f"Safety violation ({e.violation_type}): {e}"
        except Exception as e:
            elapsed = time.time() - start
            if self._governance:
                self._governance.record_call(name, kwargs, str(e), elapsed)
            # 与内置工具的错误回传策略统一：把错误作为字符串返回给 LLM，
            # 而不是 re-raise 炸掉整轮；完整 traceback 记入日志，不静默吞。
            logger.exception("Tool execution error: %s", name)
            return f"Tool execution error: {e}"
        finally:
            # ── Phase 5A observability ──
            # 成功与异常路径统一记录调用与耗时。Lazy import 避免
            # tools↔server 循环导入；观测永不打断主链路（原则 11）。
            try:
                from ant.server.observability import observe_tool

                observe_tool(name, time.time() - start)
            except Exception:
                pass

    @classmethod
    def with_builtins(cls, governance: ToolGovernance | None = None) -> "ToolRegistry":
        """Created a ToolRegistry with builtin tools already registered"""
        registry = cls(governance=governance)
        registry.register(read_file)
        registry.register(write_file)
        registry.register(edit_file)
        registry.register(bash)

        return registry
