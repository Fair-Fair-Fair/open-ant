"""Configuration management with hot reload support."""
import logging
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer


class LLMConfig(BaseModel):
    """LLM provider configuration."""

    provider: str
    model: str
    api_key: str
    api_base: str | None = None
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    # 4096 fits a 160k-token context window; the old 2048 default silently
    # capped every response to half the budget (context_guard defaults).
    max_tokens: int = Field(default=4096, gt=0)
    timeout: float = Field(default=120.0, gt=0)
    """Per-request timeout in seconds (applied by the litellm Router)."""
    num_retries: int = Field(default=2, ge=0)
    """Number of automatic retries for transient LLM failures (Router)."""
    fallbacks: list[str] = Field(default_factory=list)
    """Backup model names, tried in order when the primary model fails."""
    summarize_model: str | None = None
    """Small dedicated model for context compaction. None = use the main
    model (config.llm.model) for summarization."""

    @field_validator("api_base")
    @classmethod
    def api_base_must_be_url(cls, v: str | None) -> str | None:
        if v is not None and not v.startswith(("http://", "https://")):
            raise ValueError("api_base must be a valid URL")
        return v


class BraveWebSearchConfig(BaseModel):
    """Configuration for web search provider"""

    provider: Literal["brave"] = "brave"
    api_key: str


class TavilyWebSearchConfig(BaseModel):
    """Configuration for Tavily web search provider"""

    provider: Literal["tavily"] = "tavily"
    api_key: str


class Crawl4AIWebSearchConfig(BaseModel):
    """Configuration for web search provider"""
    provider: Literal["crawl4ai"] = "crawl4ai"


class LangChainWebReadConfig(BaseModel):
    """Configuration for LangChain web read provider"""
    provider: Literal["langchain"] = "langchain"


class MemoryConfig(BaseModel):
    """Configuration for RAG memory system"""

    enabled: bool = False
    provider: Literal["chroma"] = "chroma"
    persist_directory: Path = Field(default=Path(".memory"))
    embedding_model: str = "BAAI/bge-small-zh-v1.5"
    embedding_provider: str | None = None  # "litellm" 或 "sentence_transformers"，空则自动判断

    # ── Phase 3 backend selection (production defaults) ──
    vector_backend: Literal["chroma", "qdrant"] = "qdrant"
    """Vector store backend. ``qdrant`` is the Phase-3 production default
    (dense + BM25 sparse dual vectors, server-side prefetch + RRF);
    ``chroma`` keeps the legacy local backend for dev/offline."""
    embedding_cache_enabled: bool = True
    """Cache embedding vectors in Redis (sha256(text) → vector, 30-day TTL).
    A Redis outage degrades to direct computation with a warning — it never
    breaks retrieval (design principle 11)."""
    graph_enabled: bool = True
    """Neo4j memory graph (Phase 3C). False = vector-only memory."""
    top_k: int = Field(default=5, gt=0, le=20)
    extraction_threshold: int = Field(default=5, gt=0)
    min_importance: int = Field(default=5, ge=1, le=10)
    merge_top_k: int = Field(default=3, gt=0, le=10)
    merge_similarity: float = Field(default=0.85, gt=0.0, lt=1.0)
    # OpenClaw-aligned chunking: ~500 tokens with a 50-token overlap window.
    # (Chinese: 1 char ≈ 1 token, so 500 chars ≈ 500 tokens.)
    chunk_size: int = Field(default=500, gt=0, le=10000)
    chunk_overlap: int = Field(default=50, ge=0, le=2000)
    docs_path: str | None = None
    doc_similarity_threshold: float = Field(default=0.75, gt=0.0, lt=1.0)

    # ── Hybrid retrieval (OpenClaw-aligned: vector + keyword dual index) ──
    hybrid_enabled: bool = True
    """False = pure semantic search (legacy behaviour)."""
    fusion_mode: Literal["rrf", "weighted"] = "rrf"
    """How vector and BM25 results are combined.

    ``rrf``      — Reciprocal Rank Fusion: rank-based, immune to score
                   scale mismatch (default; recommended).
    ``weighted`` — OpenClaw-style normalized weighted sum (70/30)."""
    vector_weight: float = Field(default=0.7, ge=0.0, le=1.0)
    bm25_weight: float = Field(default=0.3, ge=0.0, le=1.0)
    score_threshold: float = Field(default=0.0, ge=0.0, lt=1.0)
    """Drop fused results below this normalized score. 0 = disabled."""
    diversity_by_source: bool = True
    """Keep the top hit per source first, then fill — prevents one long
    document from crowding out all others in the context window."""
    reranker: Literal["none", "cross_encoder"] = "none"
    """Optional second-stage rerank. ``cross_encoder`` needs the model
    available locally (offline cache) and degrades gracefully otherwise."""
    reranker_model: str = "BAAI/bge-reranker-base"
    # ── Phase 5E: sparse vector generator (hybrid retrieval) ──
    sparse_model: Literal["fastembed", "jieba"] = "fastembed"
    """Sparse vector generator for hybrid retrieval.

    ``fastembed`` — BM25 via the fastembed ONNX model (default; the
                   original Phase-3 behaviour; word-level, English-centric).
    ``jieba``    — Chinese word segmentation with a stable hashed term
                   index (better on Chinese corpora; does NOT load the
                   fastembed model, saving its memory).

    The two generators use different index spaces — never mix them in
    one collection; rebuild (delete_by_filter or recreate) after
    switching."""
    query_rewrite_enabled: bool = False
    """Phase 5A: LLM query rewrite before retrieval (opt-in, default off).

    Read directly by ``MemoryRetriever._rewrite_query`` — the old getattr
    fallback stays for compat with fake configs, but this is the real
    YAML-configurable field (``memory.query_rewrite_enabled``)."""


class TelegramConfig(BaseModel):
    """Telegram platform configuration"""

    enabled: bool = True
    bot_token: str
    allowed_user_ids: list[str] = Field(default_factory=list)


class DiscordConfig(BaseModel):
    """Discord platform configuration"""

    enabled: bool = True
    bot_token: str
    channel_id: str | None = None
    allowed_user_ids: list[str] = Field(default_factory=list)


class SourceSessionConfig(BaseModel):
    """Source session configuration"""
    session_id: str


class ChannelConfig(BaseModel):
    """Channel configuration"""

    enabled: bool = True
    telegram: TelegramConfig | None = None
    discord: DiscordConfig | None = None


class AuthConfig(BaseModel):
    """WebSocket / HTTP API authentication (Phase 4A)."""

    enabled: bool = True
    token_env: str = "OPEN_ANT_API_TOKEN"
    """Environment variable holding the static API token. When it is empty
    AND no DB key source is available, auth degrades to the Phase 0 banner
    behaviour: loopback-only trust with a warning (default user ``local``)."""
    db_keys: bool = True
    """Also validate tokens against the ``api_keys`` table (needs the
    context's MySQL session factory). The static token is checked first."""


class RateLimitConfig(BaseModel):
    """Per-message rate limiting for WebSocket clients (Phase 4A)."""

    enabled: bool = True
    window_seconds: int = Field(default=60, gt=0)
    max_requests_per_window: int = Field(default=60, gt=0)
    redis_url_env: str = "REDIS_URL"
    """Env var holding the Redis URL (read via InfraSettings fallback)."""


class ApiConfig(BaseModel):
    """HTTP API configuration"""

    host: str = "127.0.0.1"
    port: int = Field(default=8000, gt=0, lt=65536)
    # Phase 4A: authentication + rate limiting
    auth: AuthConfig = Field(default_factory=AuthConfig)
    rate_limit: RateLimitConfig = Field(default_factory=RateLimitConfig)


# ── Phase 1 infra backend selection ────────────────────────────────────


class StorageConfig(BaseModel):
    """Conversation history storage backend."""

    backend: Literal["mysql", "jsonl"] = "mysql"
    """mysql = MySQL via asyncmy (production default); requires .env
    credentials; jsonl = legacy JSONL files (dev / tests)."""


class BusConfig(BaseModel):
    """Event bus transport backend."""

    backend: Literal["rabbitmq", "memory"] = "rabbitmq"
    """rabbitmq = aio-pika AMQP (production default); memory = in-process
    EventBus pub/sub (dev / tests)."""


# ── Sandbox configuration ───────────────────────────────────────────────


class PathSandboxConfig(BaseModel):
    """Filesystem access restrictions for the agent sandbox."""

    enabled: bool = True
    allowed_dirs: list[str] = Field(default_factory=list)
    """Extra directories (relative to workspace or absolute) allowed for
    read/write.  The workspace itself is always allowed."""
    blocked_patterns: list[str] | None = None
    """Glob patterns to block even inside allowed dirs.
    ``None`` = use built-in defaults (config files, .history/, .memory/, etc.)."""
    allow_all: bool = False
    """If True, disable path sandbox entirely (opt-in override)."""


class CommandSandboxConfig(BaseModel):
    """Shell command execution restrictions for the agent sandbox."""

    enabled: bool = True
    default_timeout: int = Field(default=30, ge=1, le=300)
    """Max seconds a command may run before being killed."""
    max_output_size: int = Field(default=100_000, ge=1_000)
    """Max characters returned from stdout+stderr combined."""
    blocked_patterns: list[str] | None = None
    """Regex patterns that block command execution. ``None`` = use built-in defaults."""
    allowed_patterns: list[str] = Field(default_factory=list)
    """Explicit allowlist overrides — these commands always pass regardless of blocked_patterns."""
    working_dir: str | None = None
    """Restrict command working directory. ``None`` = workspace root."""

    # ── Docker container sandbox ──
    backend: Literal["host", "docker"] = "docker"
    """Execution backend. ``host`` = native subprocess (current behaviour).
    ``docker`` = isolated container with ``docker run --rm``."""
    docker_image: str = "open-ant-sandbox"
    """Docker image name for the sandbox container."""
    docker_url: str | None = None
    """Docker daemon URL. ``None`` = local daemon via ``docker`` CLI.
    Set to ``ssh://user@host`` for a remote Docker host."""
    docker_user: str | None = None
    """容器内运行用户，如 ``1000:1000`` 或 ``nobody``；``None`` = 镜像默认用户。"""
    network_mode: str = "none"
    """Container network mode. ``none`` = completely isolated (recommended)."""
    memory_limit: str = "256m"
    """Memory limit for the container (e.g. ``128m``, ``512m``)."""
    cpu_limit: float = Field(default=1.0, ge=0.1, le=8.0)
    """CPU limit for the container (cores)."""
    read_only_rootfs: bool = True
    """Mount the container root filesystem as read-only."""
    tmpfs_size: str = "64m"
    """Size of the writable ``/tmp`` tmpfs mount."""
    workspace_mount_mode: Literal["ro", "rw"] = "rw"
    """How the workspace directory is mounted inside the container.
    ``ro`` = read-only (recommended — the agent cannot modify real files via bash)."""
    docker_workspace_path: str | None = None
    """Path to the workspace *on the Docker host*.  Only needed when using
    a remote Docker daemon (``docker_url`` is set) and the workspace needs
    to be bind-mounted into the container.

    Example: if your workspace is at ``/root/open-ant-workspace`` on the
    remote VM, set this to ``/root/open-ant-workspace``."""


class NetworkSandboxConfig(BaseModel):
    """Outbound HTTP(S) restrictions for the agent sandbox."""

    enabled: bool = True
    block_private_ips: bool = True
    """Block requests to 10.x, 192.168.x, 172.16-31.x, 127.x, ::1."""
    block_file_urls: bool = True
    """Block ``file://`` scheme requests."""
    allowed_domains: list[str] = Field(default_factory=list)
    """If non-empty, *only* these domains (and subdomains via ``*.example.com``) are allowed."""
    denied_domains: list[str] = Field(default_factory=list)
    """Domains always blocked, regardless of allowed_domains."""


class SandboxConfig(BaseModel):
    """Top-level sandbox configuration.  All sub-sandboxes default to safe values."""

    enabled: bool = True
    """Master switch — when ``False`` ALL sandbox checks are bypassed."""
    path: PathSandboxConfig = Field(default_factory=PathSandboxConfig)
    command: CommandSandboxConfig = Field(default_factory=CommandSandboxConfig)
    network: NetworkSandboxConfig = Field(default_factory=NetworkSandboxConfig)


# ── Tool execution configuration ─────────────────────────────────────────


class ToolConfig(BaseModel):
    """Tool execution tuning (harness pipeline)."""

    default_timeout: int = Field(default=120, ge=1, le=600)
    """Max seconds a single tool call may run before being cancelled."""
    parallel_writes: bool = False
    """Whether write-class tools (write_file/edit_file) may run in parallel.
    Default False: writes stay serial to avoid same-file races."""


class PipelineConfig(BaseModel):
    """Agent harness pipeline tuning."""

    max_iterations: int = Field(default=10, ge=1, le=50)
    """Max "LLM thinks → tool round" cycles per turn."""
    max_parallel_tools: int = Field(default=8, ge=1, le=32)
    """Max independent tool calls executed concurrently per round."""


# ── Guardrail configuration ──────────────────────────────────────────────


class InputGuardrailConfig(BaseModel):
    """Input validation and prompt injection protection."""

    enabled: bool = True
    max_message_length: int = Field(default=10_000, ge=0)
    """Max characters in a single user message. 0 = unlimited."""
    sanitize_control_chars: bool = True
    """Strip ASCII control characters (except \\n, \\r, \\t) from user input."""
    detect_injection: bool = True
    """Scan for prompt injection patterns in user messages."""
    block_injection: bool = True
    """When True, matching messages are blocked. When False, only logged (audit mode)."""
    blocked_patterns: list[str] | None = None
    """Custom regex patterns for injection detection. None = use built-in defaults."""
    judge_enabled: bool = False
    """Phase 4C/5A: opt-in LLM-judge layer for input injection review.

    This is the real, YAML-configurable field (``guardrails.input.
    judge_enabled``) behind the ``getattr(config.input, "judge_enabled",
    False)`` read in ``guardrails.Guardrails`` — with the field present the
    getattr resolves to it and YAML actually takes effect.  It is the switch
    counterpart of the ``output.llm_judge`` knobs container
    (:class:`LlmJudgeConfig`); the two were named differently across phases
    and this docstring records that they describe the same feature."""


class LlmJudgeConfig(BaseModel):
    """LLM-based content judgement (Phase 4C, consumed by the content-safety
    agent). Only ``enabled`` is settled here; the remaining knobs are read
    via ``getattr`` by the consuming agent for forward compatibility.

    Phase 5A: this is the *knobs* container under ``guardrails.output.
    llm_judge``; the on/off switch the guardrails facade reads lives on the
    input side as ``guardrails.input.judge_enabled`` (see
    :class:`InputGuardrailConfig`)."""

    enabled: bool = False


class OutputGuardrailConfig(BaseModel):
    """Output sanitization and content policy enforcement."""

    enabled: bool = True
    redact_secrets: bool = True
    """Scan and redact API keys, tokens, private keys from agent responses."""
    max_output_length: int = Field(default=100_000, ge=0)
    """Max characters in agent response. 0 = unlimited."""
    detect_tool_injection: bool = True
    """Scan tool results for prompt injection before they enter LLM context."""
    tool_result_action: Literal["warn", "strip", "block"] = "warn"
    """Action when injection is detected in a tool result.
    - ``warn``: prepend ⚠️ security warning (default — agent sees result + warning)
    - ``strip``: remove the injected portion using regex
    - ``block``: replace entire tool result with safety message"""
    redact_patterns: list[str] | None = None
    """Custom regex patterns for secret redaction. None = use built-in defaults."""
    blocked_patterns: list[str] | None = None
    """Content policy patterns — responses matching these are replaced with a block message."""
    redact_buffer_chars: int = Field(default=128, ge=0, le=4096)
    """Streaming redaction buffer size in characters. 0 = redaction buffer
    disabled (streamed tokens are released immediately, unredacted)."""
    llm_judge: LlmJudgeConfig = Field(default_factory=LlmJudgeConfig)
    """Optional LLM judge stage for content policy (Phase 4C)."""


class GuardrailConfig(BaseModel):
    """Top-level guardrail configuration. Master switch controls all."""

    enabled: bool = True
    """Master switch — when False ALL guardrail checks are bypassed."""
    input: InputGuardrailConfig = Field(default_factory=InputGuardrailConfig)
    output: OutputGuardrailConfig = Field(default_factory=OutputGuardrailConfig)


class ObservabilityConfig(BaseModel):
    """Metrics / structured logging (Phase 4B, consumed by the observability
    agent — it reads but does not write this config)."""

    metrics_enabled: bool = True
    json_logs: bool = True


class Config(BaseModel):
    """Main configuration for step 00."""

    workspace: Path
    llm: LLMConfig
    default_agent: str
    agents_path: Path = Field(default=Path("agents"))
    skills_path: Path = Field(default=Path("skills"))

    # 12-cron-heartbeat
    crons_path: Path = Field(default=Path("crons"))

    memories_path: Path = Field(default=Path("memories"))

    logging_path: Path = Field(default=Path(".logs"))
    history_path: Path = Field(default=Path(".history"))
    event_path: Path = Field(default=Path(".events"))
    websearch: BraveWebSearchConfig | TavilyWebSearchConfig | None = None
    webread: Crawl4AIWebSearchConfig | LangChainWebReadConfig | None = None
    channels: ChannelConfig = Field(default_factory=ChannelConfig)
    sources: dict[str, SourceSessionConfig] = Field(default_factory=dict)
    default_delivery_source: str | None = None
    # 10-websocket
    api: ApiConfig = Field(default_factory=ApiConfig)

    # Phase 1 infra: storage (mysql|jsonl) + bus (rabbitmq|memory).
    # Defaults are the production defaults.
    storage: StorageConfig = Field(default_factory=StorageConfig)
    bus: BusConfig = Field(default_factory=BusConfig)

    # 11-multi-agent-routing
    routing: dict = Field(default_factory=lambda: {"bindings": []})

    # 16-rag-memory
    memory: MemoryConfig = Field(default_factory=MemoryConfig)

    # sandbox — harness security boundary
    sandbox: SandboxConfig = Field(default_factory=SandboxConfig)

    # guardrails — input/output content safety layer
    guardrails: GuardrailConfig = Field(default_factory=GuardrailConfig)

    # Phase 2: tool execution + pipeline tuning (harness)
    tools: ToolConfig = Field(default_factory=ToolConfig)
    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)

    # Phase 4B observability — consumed by the observability agent
    observability: ObservabilityConfig = Field(default_factory=ObservabilityConfig)

    @model_validator(mode="after")
    def resolve_paths(self) -> "Config":
        """Resolve relative paths to absolute using workspace."""
        for field_name in (
            "agents_path",
            "skills_path",
            "history_path",
            "logging_path",
            "event_path",
            "crons_path",
            "memories_path",
        ):
            path = getattr(self, field_name)
            if not path.is_absolute():
                setattr(self, field_name, self.workspace / path)

        # Resolve memory persist_directory
        if self.memory and not self.memory.persist_directory.is_absolute():
            self.memory.persist_directory = self.workspace / self.memory.persist_directory

        return self

    @classmethod
    def load(cls, workspace_dir: Path) -> "Config":
        """Load configuration from workspace directory."""
        config_data = cls._load_merged_configs(workspace_dir)
        config_data["workspace"] = workspace_dir
        return cls.model_validate(config_data)

    @classmethod
    def _load_merged_configs(cls, workspace_dir: Path) -> dict[str, Any]:
        """Load and merge user and runtime config files"""
        config_data: dict[str, Any] = {}

        user_config = workspace_dir / "config.user.yaml"
        runtime_config = workspace_dir / "config.runtime.yaml"

        if user_config.exists():
            with open(user_config) as f:
                config_data = cls._deep_merge(config_data, yaml.safe_load(f) or {})
        if runtime_config.exists():
            with open(runtime_config) as f:
                config_data = cls._deep_merge(config_data, yaml.safe_load(f) or {})

        return config_data

    @staticmethod
    def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """Deep merge override dict into base dict"""
        result = base.copy()

        for key, value in override.items():
            if(
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = Config._deep_merge(result[key], value)
            else:
                result[key] = value

        return result

    def _set_nested(self, obj: dict, key: str, value: Any) -> None:
        """Set a nested value in a dict using dot notation"""
        keys = key.split(".")
        for k in keys[:-1]:
            if k not in obj or not isinstance(obj[k], dict):
                obj[k] = {}
            obj = obj[k]
        obj[keys[-1]] = value

    def _set_config_value(self, config_path: Path, key: str, value: Any) -> None:
        """Update a config value in a yaml file"""
        # Load existing or start fresh
        if config_path.exists():
            with open(config_path) as f:
                data = yaml.safe_load(f) or {}
        else:
            data = {}

        if isinstance(value, BaseModel):
            value = value.model_dump()

        # Update the key(supports nested via dot notation)
        self._set_nested(data, key, value)

        # Write back
        with open(config_path, "w") as f:
            yaml.safe_dump(data, f)

    def set_user(self, key: str, value: Any) -> None:
        """Set a config value for the user config file"""
        self._set_config_value(self.workspace / "config.user.yaml", key, value)

    def set_runtime(self, key: str, value: Any) -> None:
        """Set a config value for the runtime config file.

        Also updates the in-memory Config object immediately so API lookups
        (e.g. source→session_id) take effect without a server restart.
        """
        self._set_config_value(self.workspace / "config.runtime.yaml", key, value)

        # Keep in-memory state in sync — split by dots, update the right field
        keys = key.split(".")
        if keys[0] == "sources" and len(keys) == 2:
            if not isinstance(value, SourceSessionConfig):
                value = SourceSessionConfig(**value) if isinstance(value, dict) else value
            self.sources[keys[1]] = value

    def reload(self) -> bool:
        """Re-load config.user.yaml and merge with runtime"""
        try:
            config_data = self._load_merged_configs(self.workspace)
            config_data["workspace"] = self.workspace

            # Create new instance and copy values
            new_config = Config.model_validate(config_data)

            # Update all fields from new config
            for field_name in Config.model_fields:
                setattr(self, field_name, getattr(new_config, field_name))

            return True
        except Exception as e:
            logging.debug("Config reload failed: %s", e)
            return False


class ConfigHandler(FileSystemEventHandler):
    """Handles config file modification events"""
    def __init__(self, config: Config):
        self._config = config

    def on_modified(self, event):
        """Reload config when config.user.yaml changes"""
        if not event.is_directory and event.src_path.endswith("config.user.yaml"):
            logging.info("Config file modified, reloading...")
            success = self._config.reload()
            if success:
                logging.info("Config reloaded successfully")
            else:
                logging.warning("Config reload failed")

    def on_created(self, event):
        """Handle file creation (some editors delete+create on save)"""
        if not event.is_directory and event.src_path.endswith("config.user.yaml"):
            logging.info("Config file created, reloading...")
            success = self._config.reload()
            if success:
                logging.info("Config reloaded successfully")
            else:
                logging.warning("Config reload failed")


"""Observer (观察者)：核心组件，在后台线程中运行，负责向操作系统注册监控路径并监听事件，
当文件系统事件发生时，会调用相应的回调函数。它管理着所有已注册的观察者，并在事件发生时，根据事件的类型调用相应的回调函数。"""


class ConfigReloader:
    """Manages watchdog observe for config hot reload"""
    def __init__(self, config: Config):
        self._config = config
        self._observer = Observer()

    def start(self) -> None:
        """Start watchdog config file for changes"""
        handler = ConfigHandler(self._config)
        self._observer.schedule(handler, str(self._config.workspace), recursive=False)
        self._observer.start()
        logging.info("Config reloader started, watching: %s", self._config.workspace)

    def stop(self) -> None:
        """Stop watching"""
        self._observer.stop()
        self._observer.join()
        del self._observer
