from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from re import Pattern
from typing import TYPE_CHECKING

from ant.core.agent import Agent
from ant.core.events import EventSource
from ant.utils.config import SourceSessionConfig

if TYPE_CHECKING:
    from ant.core.context import SharedContext


@dataclass
class Binding:
    """A routing binding that matches sources to agents"""

    agent: str
    value: str
    tier: int = field(init=False)
    pattern: Pattern = field(init=False)

    def __post_init__(self):
        # 非字符串 value（历史 /route bug 存过 list）直接判为构造错误
        if not isinstance(self.value, str):
            raise TypeError(f"Binding.value 必须是字符串，got {type(self.value).__name__}")
        self.pattern = re.compile(f"^{self.value}$")
        self.tier = self._compute_tier()

    def _compute_tier(self) -> int:
        """Compute specificity tier"""
        if not any(c in self.value for c in r".*+?[]()|^$"):
            return 0
        if ".*" in self.value:
            return 2
        return 1


@dataclass
class RoutingTable:
    """Routes sources to agents using regex bindings"""

    context: SharedContext
    bindings: list[Binding] | None = field(default=None, init=False)
    _config_hash: int | None = field(default=None, init=False)

    def _load_bindings(self) -> list[Binding]:
        """Load and sort bindings from config, Cached until config changes"""
        bindings_data = self.context.config.routing.get("bindings", [])
        # 历史脏数据（如 /route 曾把 list 存进 value）不可 hash，退化为每次重建
        try:
            current_hash = hash(tuple((b["agent"], b["value"]) for b in bindings_data))
        except TypeError:
            current_hash = None

        if self.bindings is not None and self._config_hash == current_hash:
            return self.bindings

        # Rebuild；单个绑定编译失败（坏正则 / 非字符串）只跳过它，不让路由整体崩溃
        logger = logging.getLogger(__name__)
        bindings_with_order = []
        for i, b in enumerate(bindings_data):
            try:
                binding = Binding(agent=b["agent"], value=b["value"])
            except (re.error, TypeError) as e:
                logger.warning(f"跳过无效路由绑定 {b.get('value')!r}: {e}")
                continue
            bindings_with_order.append((binding, i))
        bindings_with_order.sort(key=lambda x: (x[0].tier, x[1]))
        self.bindings = [b for b, _ in bindings_with_order]
        self._config_hash = current_hash

        return self.bindings

    def resolve(self, source: str) -> str:
        """return agent_id for source, falling back to default_agent if no match"""
        for binding in self._load_bindings():
            if binding.pattern.match(source):
                return binding.agent
        return self.context.config.default_agent

    async def get_or_create_session_id(self, source: EventSource) -> str:
        """Get existing or create new session_id source"""
        source_str = str(source)

        source_session = self.context.config.sources.get(source_str)
        if source_session:
            existing = await self.context.history_store.get_session_info(
                source_session.session_id
            )
            if existing:
                return source_session.session_id
            logger = logging.getLogger(__name__)
            logger.warning(f"Cached session {source_session.session_id} not found in history, creating new")  # noqa: E501
            self.context.config.sources.pop(source_str, None)

        agent_id = self.resolve(source_str)
        agent_def = self.context.agent_loader.load(agent_id)
        agent = Agent(agent_def, self.context)
        session = await agent.new_session(source)

        #Cache the session
        self.context.config.set_runtime(
            f"sources.{source_str}", SourceSessionConfig(session_id=session.session_id)
        )

        return session.session_id

    def persist_binding(self, source_pattern: str, agent_id: str) -> None:
        """Add and persist a routing binding to config,user.yaml"""
        bindings = self.context.config.routing.get("bindings", [])
        bindings.append({
            "agent": agent_id,
            "value": source_pattern
        })
        self.context.config.set_runtime(
            "routing.bindings", bindings
        )

    def config_source_session_cache(
            self, source_str: str, session_id: str | None
    ) -> None:
        """Config session cache for a source"""
        if session_id is None:
            if source_str in self.context.config.sources:
                del self.context.config.sources[source_str]
                self.context.config.set_runtime(
                    "sources", self.context.config.sources
                )
        else:
            self.context.config.set_runtime(
                f"sources.{source_str}", SourceSessionConfig(session_id=session_id)
            )