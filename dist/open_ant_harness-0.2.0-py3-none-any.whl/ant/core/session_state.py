"""Session state container with persistence helpers."""

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from litellm.types.completion import ChatCompletionMessageParam as Message

from ant.core.history import HistoryMessage

if TYPE_CHECKING:
    from ant.core.agent import Agent
    from ant.core.context import SharedContext
    from ant.core.events import EventSource


@dataclass
class SessionState:
    """Pure conversation state + persistence."""

    session_id: str
    agent: "Agent"
    messages: list[Message]
    source: "EventSource"
    shared_context: "SharedContext"
    memory_context: str = field(default="")
    _last_extracted_idx: int = field(default=0, repr=False)

    async def add_message(self, message: Message) -> None:
        """Add message to in-memory list + persist."""
        self.messages.append(message)
        history_msg = HistoryMessage.from_message(message)
        await self.shared_context.history_store.save_message(self.session_id, history_msg)

    def build_messages(self) -> list[Message]:
        """Build messages list with system prompt."""
        system_prompt = self.shared_context.prompt_builder.build(self)
        messages: list[Message] = [{"role": "system", "content": system_prompt}]
        messages.extend(self.messages)
        return messages
