"""Memory provider package."""
