"""Agent worker for executing agent jobs
Agent 工作模块 —— 负责接收入站事件并将其分发给对应的 Agent 会话执行器。
核心职责：
  1. 监听事件总线上的 InboundEvent（用户消息等入站事件）
  2. 根据事件中的 session_id 查找对应的 Agent 定义
  3. 创建/恢复 Agent 会话，执行聊天或斜杠命令
  4. 将结果通过 OutboundEvent 发布回事件总线
  5. 对异常会话进行有限次数的自动重试
"""
import asyncio
import json
import logging
from dataclasses import replace  # 用于不可变 dataclass 的字段替换（如重试时递增 retry_count）
from typing import TYPE_CHECKING, Union

from ant.core.agent import Agent  # Agent 核心类，封装 LLM 对话逻辑
from ant.core.events import (
    AgentEventSource,
    DispatchEvent,
    DispatchResultEvent,
    InboundEvent,
    OutboundEvent,
    StreamChunkEvent,
)
from ant.utils.def_loader import DefNotFoundError  # Agent/Skill 定义加载失败的异常

from .dedup import is_processed, mark_processed  # Phase 1: 幂等消费
from .observability import record_event_consumed  # Phase 5A observability
from .worker import SubscribeWorker  # 基类：提供事件订阅型 Worker 的基础能力

if TYPE_CHECKING:
    from ant.core.agent import AgentDef
    from ant.core.context import SharedContext

# 会话失败后的最大重试次数；超过此次数将直接返回错误给用户
MAX_RETRIES = 3

logger = logging.getLogger(__name__)

ProcessableEvent = Union[InboundEvent, DispatchEvent]


class AgentWorker(SubscribeWorker):
    """Dispatches events to session executors
    事件分发器：订阅 InboundEvent，为每个事件创建异步任务来执行 Agent 会话。
    继承自 SubscribeWorker，具备 Worker 的生命周期管理能力。
    """

    def __init__(self, context: "SharedContext") -> None:
        """初始化 AgentWorker

        Args:
            context: 全局上下文对象，包含 eventbus、history_store、agent_loader、
                command_registry 等共享组件
        """
        super().__init__(context)

        self._semaphores: dict[str, asyncio.Semaphore] = {}

        # ── Phase 4E: session task registry (worker-side subagent
        # cancellation).  Keyed by the *spawning* session: for a
        # DispatchEvent (subagent run) that is its parent_session_id, so
        # cancelling a session finds and cancels every subagent task it
        # spawned in O(1).  Main-session tasks (InboundEvent, no parent)
        # are keyed by their own session_id.
        #
        # Cancellation boundary: the registry is per-process.  In rabbitmq
        # mode (multi-worker / multi-process) a subagent may run in another
        # process and its task is invisible here — cross-process cancellation
        # is not possible.  The cascade only covers the single-process model
        # (memory/jsonl backends or one local worker).
        self._session_tasks: dict[str, set[asyncio.Task]] = {}

        # 在事件总线中订阅 InboundEvent 类型的事件，回调函数为 dispatch_event
        # 每当有用户消息等入站事件时，都会触发 dispatch_event
        self.context.eventbus.subscribe(InboundEvent, self.dispatch_event)
        self.context.eventbus.subscribe(DispatchEvent, self.dispatch_event)
        self.logger.info("AgentWorker subscribed to InboundEvent and DispatchEvent events")

    async def dispatch_event(self, event: InboundEvent) -> None:
        """Create executor task for typed event.
        事件分发入口：根据事件中的 session_id 查找会话信息，加载对应 Agent 定义，
        然后以异步任务的方式启动会话执行（不阻塞当前事件循环）。

        流程：
          1. 通过 session_id 从 history_store 获取会话元信息（包含 agent_id）
          2. 通过 agent_id 从 agent_loader 加载 Agent 定义（prompt、工具列表等）
          3. 创建异步任务 exec_session 来执行实际的对话逻辑

        Args:
            event: 入站事件，包含 session_id、content（用户消息）、retry_count 等字段
        """
        # Phase 5A observability：事件消费计数（观测永不打断主链路，原则 11；
        # helper 不抛，接线处仍防御）。
        try:
            record_event_consumed(event)
        except Exception:
            pass

        # Phase 1 幂等消费（仅 rabbitmq 模式）：broker 是 at-least-once 投递，
        # 崩溃/nack 重投会带上同一个 message_id。已处理过的直接返回——
        # 订阅包装在 handler 正常返回后自动 ack，重复消息就此消化。
        # 事件上没有 message_id（如 jsonl 来源或重试副本）时跳过去重。
        if self.context.bus_backend == "rabbitmq":
            message_id = getattr(event, "message_id", None)
            if message_id:
                if await is_processed(self.context._session_factory, message_id):
                    self.logger.info(
                        "Message %s already processed, skipping %s",
                        message_id,
                        event.__class__.__name__,
                    )
                    return

        # 从历史记录存储中获取会话信息，session_info 中包含 agent_id（标识使用哪个 Agent）
        session_info = await self.context.history_store.get_session_info(event.session_id)

        if session_info:
            agent_id = session_info.agent_id
        else:
            logger.warning(f"Session not found: {event.session_id}, falling back to routing")
            agent_id = self.context.routing_table.resolve(str(event.source))

        # 先初始化为 None，避免 load 抛异常时 except 分支引用未赋值的局部变量（UnboundLocalError）
        agent_def = None
        try:
            # 加载 Agent 定义（包含 system prompt、可用工具、模型配置等）
            agent_def = self.context.agent_loader.load(agent_id)
        except DefNotFoundError as e:
            # Agent 定义不存在时，向用户返回错误信息并终止处理
            logger.error(f"Agent not found: {agent_id}: {e}")
            # load 失败时 agent_def 为 None，判空后回退使用解析出的 agent_id 作为响应来源
            return await self._emit_response(
                event,
                "",
                agent_def.id if agent_def is not None else agent_id,
                str(e)
            )

        # 以异步任务方式启动会话执行
        # 使用 create_task 而非 await，使事件分发不被阻塞，可以立即处理下一个事件
        # 注意这里是 create_task 而非 await，这意味着 dispatch_event 会瞬间返回，不会阻塞 EventBus 的事件分发循环。  # noqa: E501
        task = asyncio.create_task(self.exec_session(event, agent_def))
        self._register_session_task(event, task)

    async def exec_session(self, event: ProcessableEvent, agent_def: "AgentDef") -> None:
        """执行一次完整的 Agent 会话
        核心执行逻辑：
          1. 创建 Agent 实例并恢复/新建会话
          2. 判断是否为斜杠命令，如果是则走命令分发流程
          3. 否则调用 session.stream_chat() 执行流式 LLM 对话
          4. 将结果通过 StreamChunkEvent + OutboundEvent 发布到事件总线
          5. 异常时进行重试（最多 MAX_RETRIES 次），超限后返回错误

        Args:
            event: 入站事件
            agent_def: Agent 定义对象，包含 prompt、工具、模型等配置
        """
        sem = self._get_or_create_semaphore(agent_def)
        session_id = event.session_id

        async with sem:
            try:
                # 使用 Agent 定义和全局上下文创建 Agent 实例
                agent = Agent(agent_def, self.context)

                if session_id:
                    try:
                        # 尝试恢复已有会话（加载历史消息上下文）
                        session = await agent.resume_session(session_id)
                    except ValueError:
                        # 会话不存在（可能是首次对话或历史被清理），创建新会话并绑定原 session_id
                        logger.warning(f"Session {session_id} not found, creating new")
                        session = await agent.new_session(
                            source=event.source, session_id=session_id
                        )
                else:
                    # 没有 session_id 时创建全新会话，由 Agent 自动生成 session_id
                    session = await agent.new_session(source=event.source)
                    session_id = session.session_id

                # ── 斜杠命令优先处理 ──
                # 如果用户消息以 "/" 开头（如 /help、/reset），优先尝试命令分发
                if event.content.startswith("/"):
                    result = await self.context.command_registry.dispatch(
                        event.content, session
                    )
                    if result:
                        # 命令匹配并执行成功，直接返回命令结果，跳过 Agent 对话流程
                        await self._emit_response(event, result, agent_def.id)
                        logger.info(f"Command completed: {session_id}")
                        return
                    # 如果命令未匹配（result 为空），则继续走 Agent 对话流程

                collected_content = ""
                async for chunk in session.harness_stream_chat(event.content):
                    chunk_type = chunk.get("type")

                    if chunk_type == "token":
                        token = chunk["data"]
                        collected_content += token
                        await self._emit_stream_chunk(
                            event, token, agent_def.id
                        )

                    elif chunk_type == "status":
                        # Forward as structured JSON so the frontend can
                        # display it cleanly (or skip if already shown elsewhere).
                        await self._emit_stream_chunk(
                            event,
                            json.dumps({"status": chunk["data"]}, ensure_ascii=False),
                            agent_def.id,
                        )

                    elif chunk_type == "tool_result":
                        logger.debug(
                            "Tool result: %s", chunk["data"].get("name")
                        )
                        # Forward tool result to frontend as JSON so it can
                        # render a collapsible source card in real time.
                        await self._emit_stream_chunk(
                            event,
                            json.dumps({"tool_result": chunk["data"]}, ensure_ascii=False),
                            agent_def.id,
                        )

                    elif chunk_type == "done":
                        break

                    elif chunk_type == "error":
                        await self._emit_response(
                            event, "", agent_def.id, str(chunk.get("data", "Unknown error"))
                        )
                        return

                logger.info(f"Session completed: {session_id}")

                await self._emit_response(event, collected_content, agent_def.id)
                await self._mark_processed(event)
            except asyncio.CancelledError:
                # ── 级联取消（Phase 4E）──
                # 本会话任务被取消（用户中断 / 上游级联取消）：先取消以本
                # 会话为 parent 的子代理任务（它们在 _session_tasks 里按
                # parent_session_id 注册），再清理 semaphore 注册，最后
                # re-raise。边界：注册表是本进程内的——rabbitmq 多 worker
                # 模式下子代理可能运行在别的进程，无法跨进程取消（见
                # __init__ 里 _session_tasks 的说明）。
                self._cancel_subagent_tasks(session_id)
                self._maybe_cleanup_semaphores(agent_def)
                raise
            except Exception as e:
                # ── 异常处理与重试机制 ──
                logger.error(f"Session failed: {e}")

                if event.retry_count < MAX_RETRIES:
                    # 重试次数未耗尽：创建一个重试事件重新投入事件总线
                    # 使用 dataclasses.replace() 创建新事件（dataclass 不可变，不能直接修改字段）
                    retry_event = replace(
                        event,
                        retry_count=event.retry_count + 1,
                        content=".",
                    )
                    # 将重试事件发布回事件总线，AgentWorker 会再次收到并处理
                    await self.context.eventbus.publish(retry_event)
                else:
                    # 重试次数已耗尽，向用户返回错误信息
                    await self._emit_response(event, "", agent_def.id, str(e))
                    await self._mark_processed(event)

        self._maybe_cleanup_semaphores(agent_def)

    def _register_session_task(self, event: ProcessableEvent, task: asyncio.Task) -> None:
        """Register *task* in ``_session_tasks`` under its spawning session.

        Subagent runs (DispatchEvent) carry the spawning session in
        ``parent_session_id``; main-session runs (InboundEvent) have no
        parent and are keyed by their own session_id.  The task is removed
        by the done callback once it finishes (normally or cancelled).
        """
        key = getattr(event, "parent_session_id", "") or event.session_id
        self._session_tasks.setdefault(key, set()).add(task)

        def _on_done(_task: asyncio.Task) -> None:
            tasks = self._session_tasks.get(key)
            if tasks is None:
                return
            tasks.discard(_task)
            if not tasks:
                del self._session_tasks[key]

        task.add_done_callback(_on_done)

    def _cancel_subagent_tasks(self, session_id: str) -> int:
        """Cancel every running task spawned by *session_id* (its subagents).

        Called from the CancelledError path of ``exec_session``: when a
        session is cancelled, all subagent runs it dispatched are cancelled
        too so they do not keep occupying the worker / burning LLM budget.
        Returns the number of tasks cancelled; safe when the registry is
        empty.  Boundary: only covers tasks in this process (see
        ``_session_tasks`` in __init__) — rabbitmq multi-worker setups
        cannot cancel across processes.
        """
        tasks = self._session_tasks.get(session_id)
        if not tasks:
            return 0
        current = asyncio.current_task()
        cancelled = 0
        for task in list(tasks):
            if task.done() or task is current:
                continue
            task.cancel()
            cancelled += 1
        if cancelled:
            self.logger.warning(
                "Session %s cancelled: cascading cancel to %d subagent task(s)",
                session_id,
                cancelled,
            )
        return cancelled

    async def _mark_processed(self, event: ProcessableEvent) -> None:
        """Phase 1 幂等：把 message_id 记入 processed_messages。

        仅 rabbitmq 模式 + MySQL 后端有意义；jsonl 模式（无共享注册表）
        是 no-op。记录失败只记日志、不致命——它是尽力而为的记账，
        真实投递语义由 broker 的 ack/nack 保证。
        """
        if self.context.bus_backend != "rabbitmq":
            return
        message_id = getattr(event, "message_id", None)
        if not message_id:
            return
        try:
            await mark_processed(self.context._session_factory, message_id)
        except Exception as e:
            self.logger.warning(
                "Failed to mark message %s processed: %s", message_id, e
            )

    async def _emit_stream_chunk(
        self,
        event: ProcessableEvent,
        content: str,
        agent_id: str,
    ) -> None:
        """Emit a streaming chunk event."""
        stream_event = StreamChunkEvent(
            session_id=event.session_id,
            source=AgentEventSource(agent_id),
            content=content,
        )
        await self.context.eventbus.publish(stream_event)

    async def _emit_response(self,
                             event: ProcessableEvent,
                             content: str,
                             agent_id: str,
                             error: str | None = None) -> None:
        """Emit response event with content
        发送响应事件的辅助方法：将内容或错误信息封装为 OutboundEvent 并发布。

        使用场景：
          - Agent 定义不存在时返回错误
          - 斜杠命令执行完毕返回结果
          - 重试耗尽后返回最终错误

        Args:
            event: 原始入站事件，用于获取 session_id 以关联响应
            content: 响应正文内容（正常结果或空字符串）
            error: 可选的错误信息，非 None 时会转为字符串写入出站事件的 error 字段
        """
        # When content is empty but error is present, put the error into
        # content so that DeliveryWorker actually delivers it to the frontend.
        # (DeliveryWorker reads event.content, not event.error.)
        if not content and error:
            content = error

        if isinstance(event, DispatchEvent):
            result_event: OutboundEvent | DispatchResultEvent = DispatchResultEvent(
                session_id=event.session_id,
                source=AgentEventSource(agent_id),
                content=content,
                error=str(error) if error else None,  # 确保 error 为字符串类型或 None
            )
        else:
            result_event = OutboundEvent(
                session_id=event.session_id,
                source=AgentEventSource(agent_id),
                content=content,
                error=str(error) if error else None,  # 确保 error 为字符串类型或 None
            )
        await self.context.eventbus.publish(result_event)

    def _get_or_create_semaphore(self, agent_def: "AgentDef") -> asyncio.Semaphore:
        """Get existing or create new semaphore for agent"""
        if agent_def.id not in self._semaphores:
            self._semaphores[agent_def.id] = asyncio.Semaphore(
                agent_def.max_concurrency
            )
        logger.debug(
            f"Created semaphore for {agent_def.id} with value {agent_def.max_concurrency}"
        )
        return self._semaphores[agent_def.id]

    def _maybe_cleanup_semaphores(self, agent_def: "AgentDef") -> None:
        """Remove semaphores for certain agents"""
        if agent_def.id not in self._semaphores:
            return
        if not self._semaphores[agent_def.id]._waiters:
            del self._semaphores[agent_def.id]
