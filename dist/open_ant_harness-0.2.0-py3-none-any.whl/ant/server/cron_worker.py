"""Cron worker for scheduled job dispathc"""
import asyncio
import logging
import shutil
from datetime import datetime
from typing import TYPE_CHECKING

from croniter import croniter

from ant.core.agent import Agent
from ant.core.events import CronEventSource, DispatchEvent

from .observability import record_event_consumed  # Phase 5A observability
from .worker import Worker

if TYPE_CHECKING:
    from ant.core.context import SharedContext
    from ant.core.cron_loader import CronDef

logger = logging.getLogger(__name__)


def find_due_jobs(
        jobs: list["CronDef"], now: datetime | None = None
) -> list["CronDef"]:
    """Find all jobs that are due to run"""
    if not jobs:
        return []

    now = now or datetime.now()
    now_minute = now.replace(second=0, microsecond=0)

    due_jobs = []
    for job in jobs:
        try:
            if croniter.match(job.schedule, now_minute):
                due_jobs.append(job)
        except Exception as e:
            logger.warning(f"Error checking schedule for {job.id}: {e}")
            continue

    return due_jobs


class CronWorker(Worker):
    """Finds due cron jobs, publish DISPATCH events"""
    def __init__(self, context: "SharedContext"):
        super().__init__(context)

    async def run(self) -> None:
        """Check every minute for due jobs"""
        self.logger.info("CronWorker started")

        while True:
            try:
                await self._tick()
            except Exception as e:
                self.logger.error(f"Error in tick: {e}")
            await asyncio.sleep(60)

    async def _tick(self) -> None:
        """Find and dispatch due jobs via EventBus"""
        jobs = self.context.cron_loader.discover_crons()
        due_jobs = find_due_jobs(jobs)

        for cron_def in due_jobs:
            agent_def = self.context.agent_loader.load(cron_def.agent)
            agent = Agent(agent_def, self.context)
            cron_source = CronEventSource(cron_id=cron_def.id)
            session = await agent.new_session(cron_source)

            event = DispatchEvent(
                session_id=session.session_id,
                source=CronEventSource(cron_id=cron_def.id),
                content=cron_def.prompt
            )

            # Phase 5A observability：cron 任务触发计数（观测永不打断主链路）。
            try:
                record_event_consumed(event)
            except Exception:
                pass

            await self.context.eventbus.publish(event)
            self.logger.info(f"Dispatched cron job: {cron_def.id}")

            if cron_def.one_off:
                cron_path = self.context.cron_loader.config.crons_path / cron_def.id
                shutil.rmtree(cron_path)
                self.logger.info(f"Deleted one-off cron job: {cron_def.id}")